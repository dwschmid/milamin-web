MilAMin browser solver: corresponding source of spchol.wasm / spchol-mt.wasm
(https://milamin.pages.dev/about/licenses.html)

wasm-src/           our C interface to CHOLMOD (spchol.cpp), the Eigen-based BLAS layer
                    (blas_shim.cpp), the emscripten build script with the exact
                    flags (build.sh) and the compat header; GPL-2.0-or-later,
                    copyright Dani Schmid 2026
suitesparse-5.13.0/ the SuiteSparse modules compiled in: SuiteSparse_config,
                    AMD, COLAMD (BSD-3-Clause), CHOLMOD Core/Cholesky/Check
                    (LGPL-2.1-or-later) and Supernodal (GPL-2.0-or-later);
                    copyright Timothy A. Davis et al., see LICENSE.txt and
                    each module's Doc/License.txt
eigen-3.4.0/       the Eigen headers (MPL-2.0), see COPYING.MPL2

Build: install emsdk (Emscripten 6.0.3 built the shipped binaries; python
>= 3.10 on PATH), place suitesparse-5.13.0 as
wasm-src/suitesparse and eigen-3.4.0 as wasm-src/eigen, then run
wasm-src/build.sh. The Triangle mesher (triangle.out.wasm) is a separate
program built from Jonathan Shewchuk's Triangle 1.6 and is not part of this
bundle.
